There are no specific intructions before running the code.
In this code if the first input is Y then one needs to input the cylce Length and 
the second input is the no.of elements in the loop.

If the input is N then u need to tell the length of the linked list.
