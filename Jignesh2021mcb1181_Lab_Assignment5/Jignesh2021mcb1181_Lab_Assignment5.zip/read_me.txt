There is no pre-requisite to run this code.
You can Directly run this code.