The test cases given in the question is wrong when searching for element 15 they have displayed
only 2 element but there should be 4.

I have checked it by drawing the complete tree by hand and my friend also checked it and we got the same result.
