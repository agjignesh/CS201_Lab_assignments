The Text file name should be ExampleFile.txt and should be in the same directory or Folder as the source Code program. 
